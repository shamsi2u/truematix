# Astryx adoption

Astryx (https://astryx.atmeta.com) is Meta's open source design system, MIT
licensed. This site adopts its **token layer**, not its components.

## Why not the components

Astryx ships 150+ React components built on StyleX. Using them requires
React 19, a bundler and a build step. This site is static HTML served from
GitHub Pages with no build pipeline, and the project brief requires working
within the actual deployment platform. Migrating would mean rewriting both
pages as a React app and adding a build workflow — a large change with no
gain for two marketing pages.

## What is adopted

`css/theme.css` contains:

1. **Astryx scale tokens, copied verbatim** from `@astryxdesign/core` 0.7.13
   `dist/astryx.css` — spacing, radius, font size, font weight, line height,
   duration, easing, shadow, focus and z-index scales. 68 tokens.
2. **Astryx semantic colour naming** — `--color-background-card`,
   `--color-text-secondary`, `--color-border-emphasized` and so on.
3. **The TrueMatix palette**, supplying the values behind those names.

Astryx defines a theme as a set of CSS custom property overrides, so this is a
TrueMatix theme expressed in Astryx's structure. The violet and near-black
identity is unchanged, as the brief requires.

None of Astryx's shipped palettes were used. Gothic is the closest in mood and
is dark-only, but it is a desaturated grey-green that would have discarded the
brand colour.

## Weight

| | Size |
| --- | --- |
| Full `astryx.css` | 275 KB |
| Token layer only | 6 KB |

The component styles are not referenced by this site, so shipping them would
cost 269 KB for nothing.

## Upgrading

```bash
npm pack @astryxdesign/core
tar xzf astryxdesign-core-*.tgz
```

Re-copy the scale token declarations from `package/dist/astryx.css` into the
first block of `css/theme.css`. Leave the colour tokens alone — those are the
TrueMatix theme, not Astryx defaults.

## Attribution

Astryx is MIT licensed, Copyright (c) Meta Platforms, Inc. and affiliates.
Token values are reproduced under that licence. Before publication, confirm
whether attribution should also appear in the site footer.

## De-slop layer

A final block in `css/theme.css` (mirrored inline in both pages) overrides the
original styling to remove the signature of generated UI:

| Removed | Replaced with |
| --- | --- |
| 20+ radial and linear gradients, ambient violet glow ellipses | Flat surfaces, one elevation step |
| Gradient-filled headline text | Solid accent colour |
| Radii of 22px, 24px, 26px, 28px, 100px | 4px interactive, 6px container, 2px tag |
| Accent colour on badges, borders, decoration | Accent reserved for interactive state only |
| Hover glow and lift on cards and buttons | Border-colour change only |
| Pill badges with tinted fills | Ruled outlines |
| Eyebrow labels styled as chips | Plain uppercase labels |
| Centred section headings | Left-aligned |

The reasoning: ambient glow, gradient text, large soft radii and colour used
decoratively are the visual defaults of AI-generated marketing pages. Removing
them leaves hierarchy carried by type, spacing and a single rule weight, which
is both calmer and more credible for a product whose pitch is evidence.

Violet is retained but demoted — it now appears on buttons, links, the active
tab and selected options, and nowhere else.

## Light theme

Dark remains the default. Light applies when the OS asks for it, and an
explicit choice on `<html data-theme="...">` overrides both.

| Layer | Behaviour |
| --- | --- |
| `:root` | Dark values |
| `@media (prefers-color-scheme: light)` guarded by `:root:not([data-theme="dark"])` | Follows the OS |
| `:root[data-theme="light"]` / `[data-theme="dark"]` | Explicit visitor choice, stored in `localStorage` under `tmx-theme` |

A blocking inline script immediately after `<meta charset>` reads that value
before first paint, so a light-mode visitor never sees a dark flash.

Prerequisite work: roughly 56 hardcoded hex values and all
`rgba(245,243,239,…)` hairlines were replaced with tokens, since literals do
not flip with the theme. Hairlines now use `--tint-5` through `--tint-28`,
which invert alongside the palette.

Measured contrast on the light palette, against `#FBFAF8`:

| Pair | Ratio |
| --- | --- |
| Body text `#16181F` | 17.0 |
| Secondary text `#585F72` | 6.11 |
| Accent text `#4A2BC2` | 8.33 |
| Button label on accent | 7.23 |
| Error `#B3302F` | 5.96 |
| Warning `#96620C` | 4.97 |
| Success `#1E7F45` | 4.82 |

All pass WCAG AA for body text. The accent darkens from `#6C4BF6` to `#5736D6`
on light because the dark-mode violet only reaches 3.4:1 on a light background.

## Globe exclusion

The hero globe is a three.js WebGL scene. Two problems arose from the
restyling work and both are now fixed:

1. **Corrupted colour literals.** The hex-to-token pass replaced `'#31C671'`
   and `'#E5595E'` inside the globe's JavaScript with `var(--green)` and
   `var(--red)`. three.js cannot parse CSS custom properties, so pulse
   rendering failed. The literals are restored.
2. **Theme interference.** The de-slop and light layers flattened gradients,
   overrode radii and inverted surfaces that the globe depends on.

The globe is now excluded from both layers by a guard block at the end of the
stylesheet. It stays dark in light mode, framed by a border so it reads as a
deliberate inset panel rather than a mistake.

**When editing:** colours exist in two places that must agree — the CSS guard
block, and the `0x` values in the three.js source (`0x6C4BF6` for scan points,
`0x1B2140` for the wireframe). Never run a global find-and-replace for colour
values across the file; scope it to `<style>` blocks only.
