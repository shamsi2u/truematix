# TrueMatix — GitHub Pages deployment

Platform: GitHub Pages. Canonical origin: `https://www.truematix.com/`.

GitHub Pages has no redirect configuration file. There is no `.htaccess`, no
`_redirects`, no `vercel.json`. Two redirects are produced automatically by the
platform once configured correctly, and those are the only two available.

---

## 1. Repository files

| File | Purpose |
| --- | --- |
| `CNAME` | Must contain `www.truematix.com` and nothing else. This is what makes the apex redirect work |
| `.nojekyll` | Stops Jekyll processing. Without it Jekyll can rewrite output and, in a repo with a README, serve the README as the homepage |
| `404.html` | Served with a real HTTP 404 status on unmatched paths |
| `robots.txt`, `sitemap.xml`, `llms.txt` | Served as static files from root |

`CNAME` is managed by the Pages settings UI. Editing the file and editing the
custom-domain field are the same action — do not set both to different values.

## 2. DNS records

Apex `truematix.com` — four A records:

```
185.199.108.153
185.199.109.153
185.199.110.153
185.199.111.153
```

Optionally the same four as AAAA:

```
2606:50c0:8000::153
2606:50c0:8001::153
2606:50c0:8002::153
2606:50c0:8003::153
```

Subdomain `www` — one CNAME record:

```
www.truematix.com  CNAME  <github-user>.github.io.
```

Do not also create an A record for `www`. CNAME and A on the same name conflict.

## 3. Pages settings

1. **Settings → Pages → Source** → Deploy from a branch → `main` → `/ (root)`
2. **Custom domain** → `www.truematix.com` → Save
3. Wait for the DNS check to pass, then tick **Enforce HTTPS**

Enforce HTTPS only becomes available after the Let's Encrypt certificate is
issued. That typically takes minutes but can take up to 24 hours. The tick box
is greyed out until then.

## 4. Redirects this produces

| From | To | Mechanism | Status |
| --- | --- | --- | --- |
| `http://www.truematix.com/*` | `https://www.truematix.com/*` | Enforce HTTPS | 301 |
| `http://truematix.com/*` | `https://www.truematix.com/*` | Apex A records + CNAME file | 301 |
| `https://truematix.com/*` | `https://www.truematix.com/*` | Apex A records + CNAME file | 301 |
| `https://<user>.github.io/<repo>/*` | `https://www.truematix.com/*` | Automatic once custom domain is set | 301 |

All four are handled. Nothing further is required, and nothing further is
possible on this platform.

## 5. Limitations to record

- **No arbitrary redirects.** Old URLs cannot be mapped to new ones. Plan the
  URL structure before publishing, because renaming a page later leaves a hard
  404 with no redirect path.
- **No custom headers.** HSTS, CSP, X-Frame-Options and cache-control cannot be
  set. If a security header requirement appears, the site must move to a
  platform that supports it or sit behind a proxy such as Cloudflare.
- **No server-side logic.** Forms need a third-party endpoint. The current
  `mailto:` demo link needs none.
- **Trailing slashes are fixed.** `/about.html` and `/about/` are different
  URLs. Use directory form — `about/index.html` serving `/about/` — so the
  canonical URLs in the sitemap match what visitors reach.
- **Soft limits.** 1 GB repository, 100 GB bandwidth per month, 10 builds per
  hour. Not a constraint at this size.
- **Deployment is public.** Pages on a private repository requires a paid plan;
  on a free plan it builds but serves nothing.

A JavaScript redirect is not a substitute for any of the above and is not used
in this repository.

## 6. Future pages

When the gated service pages are published, create them as directories so URLs
carry a trailing slash and match the canonical tags:

```
product-authentication/index.html   ->  /product-authentication/
grey-market-detection/index.html    ->  /grey-market-detection/
```

Add each to `sitemap.xml` only once it returns 200 at its canonical URL.

## 7. Acceptance tests

Run after DNS propagates and Enforce HTTPS is on.

```bash
# Each should end at https://www.truematix.com/ with a 301 chain
curl -sIL http://truematix.com        | grep -Ei '^(HTTP|location)'
curl -sIL https://truematix.com       | grep -Ei '^(HTTP|location)'
curl -sIL http://www.truematix.com    | grep -Ei '^(HTTP|location)'

# Canonical returns 200
curl -sI https://www.truematix.com/   | head -1

# 404 returns a real 404, not 200
curl -sI https://www.truematix.com/no-such-page | head -1

# Static files resolve
curl -sI https://www.truematix.com/robots.txt   | head -1
curl -sI https://www.truematix.com/sitemap.xml  | head -1
curl -sI https://www.truematix.com/llms.txt     | head -1

# Certificate covers the canonical host
echo | openssl s_client -connect www.truematix.com:443 -servername www.truematix.com 2>/dev/null | openssl x509 -noout -subject -dates
```

Content readable without JavaScript:

```bash
curl -s https://www.truematix.com/ | grep -E '1,300,000\+|40\+|99%|2026'
```

All four must appear in the raw HTML. If any returns empty, a value has
regressed to a JavaScript-only render.
