# TrueMatix — claim confirmation review

Internal. Not for publication. Every item below is either live on the site
without evidence, or required before further pages can be written.

Status key: **BLOCKING** stops publication · **LIVE-UNVERIFIED** currently
published without evidence · **NEEDED** required to write a gated page.

---

## 1. Metrics currently published

| Claim | Location | Status | Needed |
| --- | --- | --- | --- |
| 1,300,000+ product scans verified worldwide | Trust strip | LIVE-UNVERIFIED | Actual count, system of record, as-of date |
| 40+ markets watched live | Trust strip | LIVE-UNVERIFIED | Count of distinct markets with scan activity, timeframe |
| 99% of scans resolved in under a second | Trust strip | LIVE-UNVERIFIED | p50/p95 latency from logs, measurement window, what "resolved" means |

If a number cannot be evidenced, remove the tile rather than rounding it down.
Three tiles is not a layout requirement.

## 2. Case study — grey-market diversion

| Item | Status |
| --- | --- |
| Written client permission to publish, even anonymised | BLOCKING |
| 400+ diverted units identified by serial — source record | BLOCKING |
| 4 days, leak to shutdown — dated events | BLOCKING |
| 1 distributor pinpointed — basis for attribution | BLOCKING |
| Baseline: diversion rate before deployment | NEEDED |
| Uncertainty statement: what the data could not establish | NEEDED |

Until permission is confirmed, the section must come out of production.
An anonymised case study is still a customer claim.

## 3. Product capability — mark each Live / Beta / Planned

| Capability | Site says | Actual status |
| --- | --- | --- |
| Cryptographic code signing | Live | ? Which scheme, key custody |
| Duplicate serial detection | Implied | ? |
| Impossible-travel detection | Live | ? |
| Volume-spike detection | Live | ? |
| Grey-market clustering | Live | ? Automated or analyst-run |
| Real-time alerting | Live | ? Channel, latency, configurability |
| White-label verification page | Live | ? Per-tenant or per-product-line |
| Live world map dashboard | Live | ? Real tenant data or illustrative |
| Distributor-level traceability | Live | ? Depends on assignment at pack time |
| ERP / label-printer integration | Not stated | ? |

## 4. Online brand protection — RESOLVED: second offering

Confirmed by owner: TrueMatix is positioned as providing **both** a product-
authentication platform and a managed online brand protection service. The
service is not built into the platform software.

Published on that basis. The positioning is "one company, two offerings"; the
constraint kept throughout is that the service is never described as platform
functionality:

- `/online-brand-protection/` live, with a delivery note under the opening
  paragraph: two offerings, scoped and priced separately, either works alone,
  findings delivered as reports rather than through the verification dashboard.
- Owner confirmed (11 Nov): the service also uses AI, as a separate program
  from the scan-analysis AI. Capability matrix labels delivery as
  **AI monitoring** or **analyst** —
  never as part of the authentication platform's software, since it is a
  separate program.
- `llms.txt` carries the same separation so AI engines do not attribute
  marketplace monitoring to the authentication product.

### Still required before this page is accurate in production

| Item | Status |
| --- | --- |
| Named list of marketplaces, social platforms and domain sources in scope | BLOCKING — the page promises this list at scoping |
| Who performs analyst triage, and capacity at volume | NEEDED |
| Which AI monitoring program is used, and whether it is owned or licensed | NEEDED |
| That an analyst reviews every match before it reaches the client | NEEDED — stated on the page, not yet confirmed by owner |
| Lawful basis and terms-of-service position for each monitored source | NEEDED |
| Whether this service is sold under the TrueMatix name or its own brand | NEEDED — affects the Service schema `provider` field |

The last item matters. The page currently names TrueMatix as provider in
schema. If the service trades under a different name, that is a
misattribution and must be corrected before publication.

## 5. Entity and identity

| Item | Status |
| --- | --- |
| Legal entity name and jurisdiction | NEEDED — required for Organization schema |
| Registered address | NEEDED — "GCC" is a market, not an address |
| Official social profile URLs | NEEDED — `sameAs` omitted until verified |
| Trademark status of "TrueMatix" | NEEDED before any ® or ™ |

JSON-LD currently ships name, URL, email and description only. Nothing else is
assertable.

## 6. Data and privacy — gates /privacy/

| Item | Status |
| --- | --- |
| What a scan records (IP, coarse/precise geo, device, timestamp) | NEEDED |
| Retention period per data class | NEEDED |
| Lawful basis for geolocation of consumer scans | NEEDED |
| Processor vs controller role per tenant | NEEDED |
| Sub-processors and hosting regions | NEEDED |

## 7. Hosting — gates the redirect work

| Item | Status |
| --- | --- |
| Deployment platform | RESOLVED — GitHub Pages |
| Apex vs www canonical preference | `www.truematix.com`; set in `CNAME` |
| HTTP to HTTPS redirect | Handled by Enforce HTTPS — tick after cert issues |
| Apex to www redirect | Handled by apex A records + `CNAME` file |
| Enforce HTTPS enabled | PENDING — verify in Settings → Pages |
| DNS records live | PENDING — see DEPLOYMENT.md section 2 |

All four redirect cases are covered by the platform. See DEPLOYMENT.md for
records, settings, limitations and acceptance tests. No JavaScript redirect is
used.

---

## Changes already applied

| # | Change | Reason |
| --- | --- | --- |
| 1 | Counters render final values in HTML instead of `0` | Crawlers and AI engines were extracting "0 product scans verified worldwide" |
| 2 | "Impossible to clone in bulk" rewritten to a detection claim | A printed QR can be photographed; the defensible claim is duplicate-use detection |
| 3 | "Points you to the distributor who leaked it" softened to an investigative lead | Location does not prove liability |
| 4 | "Trusted by leading consumer brands across the GCC" replaced with sector positioning | No logos, names or permissions exist |
| 5 | Globe legend labelled Illustrative | Activity is `Math.random()`, not tenant data |
| 6 | Copyright year hard-coded, JS retained as overwrite | Rendered empty without JavaScript |
| 7 | Canonical, og:url, og:site_name, twitter:card, theme-color, robots meta added | Absent |
| 8 | Organization and WebSite JSON-LD added, verified fields only | Absent |
| 9 | robots.txt, sitemap.xml, llms.txt, 404.html created | Absent |

## Still unapplied, pending answers above

- Multi-page architecture — service pages need confirmed capabilities
- FAQ blocks — answers must come from verified information
- Case study — permission blocking
- Service and BreadcrumbList schema — needs real page URLs
- `sameAs` — needs verified profile URLs
- Redirect configuration — needs platform
